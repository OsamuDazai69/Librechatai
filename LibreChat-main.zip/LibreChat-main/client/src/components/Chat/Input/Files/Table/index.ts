export { columns } from './Columns';
export { default as DataTable } from './DataTable';
export { default as TemplateTable } from './TemplateTable';
export { files } from './fakeData';
