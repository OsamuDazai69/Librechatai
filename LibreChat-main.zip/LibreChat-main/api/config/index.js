const logger = require('./winston');

module.exports = {
  logger,
};
