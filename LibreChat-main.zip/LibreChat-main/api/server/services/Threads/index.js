const manage = require('./manage');

module.exports = {
  ...manage,
};
