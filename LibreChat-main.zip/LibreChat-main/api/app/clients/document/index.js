const tokenSplit = require('./tokenSplit');

module.exports = {
  tokenSplit,
};
